using Microsoft.AspNetCore.Mvc;
using Team2Competition3.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Team2Competition3.Controllers
{
    public class NewsController : Controller
    {
        private readonly HttpClient _httpClient;

        public NewsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Index()
        {
            string apiKey = "50ec1bed729848029d182f70ed2feb09";
            string url = $"https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey={apiKey}";

            Console.WriteLine("Request URL: " + url);

            // ✅ Add required User-Agent header
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("User-Agent", "Team2Competition3 NewsApp");

            var response = await _httpClient.SendAsync(request);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"❌ API returned status code: {response.StatusCode}");
                Console.WriteLine("❗ Error Response Body:");
                Console.WriteLine(errorContent);

                return View(new List<NewsArticle>());
            }

            var json = await response.Content.ReadAsStringAsync();
            Console.WriteLine("=== API RESPONSE ===");
            Console.WriteLine(json);

            var apiResponse = JsonConvert.DeserializeObject<NewsApiResponse>(json);

            var articles = apiResponse.Articles.Select(a => new NewsArticle
            {
                SourceName = a.Source?.Name ?? "Unknown",
                Title = a.Title,
                Url = a.Url
            }).ToList();

            return View(articles);
        }
    }
}
