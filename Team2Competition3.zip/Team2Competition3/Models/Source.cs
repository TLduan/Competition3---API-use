namespace Team2Competition3.Models
{
    public class Source
    {
        public string Name { get; set; }
    }
}
