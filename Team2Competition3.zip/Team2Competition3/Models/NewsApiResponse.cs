using System.Collections.Generic;

namespace Team2Competition3.Models
{
    public class NewsApiResponse
    {
        public List<Article> Articles { get; set; }
    }
}
