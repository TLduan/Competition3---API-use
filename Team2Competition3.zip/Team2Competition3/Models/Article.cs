namespace Team2Competition3.Models
{
    public class Article
    {
        public Source Source { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
