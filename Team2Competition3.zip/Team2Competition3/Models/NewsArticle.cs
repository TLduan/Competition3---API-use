namespace Team2Competition3.Models
{
    public class NewsArticle
    {
        public string SourceName { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
